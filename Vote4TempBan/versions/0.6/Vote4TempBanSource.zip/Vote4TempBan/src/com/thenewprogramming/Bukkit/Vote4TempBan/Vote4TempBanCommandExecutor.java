package com.thenewprogramming.Bukkit.Vote4TempBan;

import java.util.ArrayList;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class Vote4TempBanCommandExecutor implements CommandExecutor {
	
	private Vote4TempBan plugin;
	
	public Vote4TempBanCommandExecutor(Vote4TempBan plugin){
		this.plugin = plugin;
	}
	
	public boolean startvote(CommandSender sender, Command cmd, String label, String[] args){
		if (!(plugin.getplayercooldown().contains(sender.getName()))){
			//if there's a voting going on, return true.
			if (!plugin.getvotingcurrently()){
				//player has to exist :P
				if (!(Bukkit.getServer().getPlayer(args[0]) == null)){
					if(args.length > 1){
						//i didn't want to make a big mess here, so i put it inside the main class.
						plugin.startvote(sender, args);
						return true;
					}
					else{
						return false;
					}
				}
				else{
					sender.sendMessage("§aThis player is not online");
					//there is no need to show the correct syntax if there's no error with that
					return true;
				}
			}
			else{
				sender.sendMessage("§aThere is already a voting going on");
				//there is no need to show the correct syntax if there's no error with that
				return true;
			}
		}
		else{
			sender.sendMessage("§aYou need to wait at least "+((plugin.getConfig().getLong("timesettings.votecooldown")/20)/60)+" min before starting a new vote");
			//there is no need to show the correct syntax if there's no error with that
			return true;
		}
	}
	
	public boolean voteyes(CommandSender sender, Command cmd, String label, String[] args){
		if (plugin.getvotingcurrently()==true){
			//check if the player has already voted
			if (plugin.getplayersvoted().contains(sender.getName())){
				sender.sendMessage("§aYou already voted");
				return true;
			}
			else{
				ArrayList<String> newplayersvoted = plugin.getplayersvoted();
				newplayersvoted.add(sender.getName());
				plugin.setplayersvoted(newplayersvoted);
				plugin.setyesvotes(plugin.getyesvotes()+1);
				sender.sendMessage("§aYou voted yes");
				return true;
			}
		
		}
		else{
			sender.sendMessage("§aThere is no voting going on");
			return true;
		}
	}
	
	public boolean voteno(CommandSender sender, Command cmd, String label, String[] args){
		if (plugin.getvotingcurrently()){
			//check if the player has already voted
			if (plugin.getplayersvoted().contains(sender.getName())){
				sender.sendMessage("§aYou already voted");
				return true;
			}
			else{
				ArrayList<String> newplayersvoted = plugin.getplayersvoted();
				newplayersvoted.add(sender.getName());
				plugin.setplayersvoted(newplayersvoted);
				plugin.setnovotes(plugin.getnovotes()+1);
				sender.sendMessage("§aYou voted no");
				return true;
			}
		}
		else{
			sender.sendMessage("§aThere is no voting going on.");
			return true;
		}
	}
	
	public boolean cancelvote(CommandSender sender, Command cmd, String label, String[] args){
		if(plugin.getvotingcurrently()){
			plugin.cancelvote(sender);
		}
		else{
			sender.sendMessage("There is no voting going on.");
		}
		return true;
	}
	
	public boolean unbanplayer(CommandSender sender, Command cmd, String label, String[] args){
		if(args[1]!= null && Bukkit.getServer().getPlayer(args[1]) != null){
			if(plugin.getplayersbanned().contains(args[1])){
				plugin.ubanplayer(sender, args[1]);
			}
			else{ sender.sendMessage("That player isn't banned."); }
		}
		else{
			sender.sendMessage("You have to give a player to unban that exists.");
		}
		return true;
	}
	
	
	@Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args){
    	if(cmd.getName().equalsIgnoreCase("vote")){
    			if(args[0].equalsIgnoreCase("yes")){
    				return voteyes(sender, cmd, label, args);
    			}
    			else if(args[0].equalsIgnoreCase("no")){
    				return voteno(sender, cmd, label, args);
    			}
    			else{
    				return false;
    			}
    	}
    	else if(cmd.getName().equalsIgnoreCase("startvote")){
    		return startvote(sender, cmd, label, args);
    	}
    	
    	else if(cmd.getName().equalsIgnoreCase("cancelvote") | (cmd.getName().equalsIgnoreCase("stopvote"))){
    		return cancelvote(sender, cmd, label, args);
    	}
    	
    	else if(cmd.getName().equalsIgnoreCase("unbanvoted")){
    		return unbanplayer(sender, cmd, label, args);
    	}
    	
    	return false; 
    }

}
