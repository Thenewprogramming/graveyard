package com.thenewprogramming.Bukkit.Vote4TempBan;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class Vote4TempBanJoinListener implements Listener {
	
	private Vote4TempBan plugin;
	
	public Vote4TempBanJoinListener(Vote4TempBan plugin) {
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
        this.plugin = plugin;
    }
	
	@EventHandler
	public void onPlayerJoin(PlayerJoinEvent event){
		int loopcount = 0;
		while (!(loopcount==plugin.getplayersbanned().size())){
			if (event.getPlayer().getName().equals(plugin.getplayersbanned().get(loopcount))){
				event.getPlayer().kickPlayer("Can't you wait 30 minutes to join again??");
			}
			loopcount += 1;
		}
	}
}